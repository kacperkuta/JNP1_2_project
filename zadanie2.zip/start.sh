g++ -Wall -Wextra -O2 -std=c++17 -c poset.cc -o poset.o
gcc -Wall -Wextra -O2 -std=c11 -c poset_example1.c -o poset_example1.o
g++ -Wall -Wextra -O2 -std=c++17 -c poset_example2.cc -o poset_example2.o
g++ poset_example1.o poset.o -o poset_example1
g++ poset_example2.o poset.o -o poset_example2